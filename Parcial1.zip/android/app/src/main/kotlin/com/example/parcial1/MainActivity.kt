package com.example.parcial1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
