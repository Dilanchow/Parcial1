import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class myApp extends StatelessWidget {
  const myApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: Color(0xff000000),
          body: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                        margin: EdgeInsets.only(top: 20, left: 30, bottom: 15),
                        height: 40,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40)),
                        child: ElevatedButton(
                          onPressed: () {},
                          child: Row(
                            children: [
                              Icon(
                                Icons.location_on_outlined,
                                color: Colors.white,
                              ),
                              Text(' Barranquilla',
                                  style: TextStyle(color: Color(0xff120000))),
                            ],
                          ),
                          style: ElevatedButton.styleFrom(
                              alignment: Alignment.centerLeft,
                              backgroundColor: Color(0xff825120)),
                        )),
                    Spacer(),
                    Container(
                      margin: EdgeInsets.only(right: 30, top: 15),
                      width: 120,
                      height: 70,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('assets/img/icono.jpg'),
                              fit: BoxFit.cover)),
                    )
                  ],
                ),
                Container(
                  child: Text('Barbershop Pepper',
                      style: TextStyle(
                          color: Color(0xfffcfcfc),
                          fontSize: 40,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.bold)),
                  alignment: Alignment.centerLeft,
                  padding: EdgeInsets.only(left: 30),
                ),
                Container(
                  alignment: Alignment.centerLeft,
                  padding: EdgeInsets.only(left: 40, top: 10, bottom: 15),
                  child: Text("Llega pa bajar el casco.",
                      style: TextStyle(
                          color: Color(0xffffffff),
                          fontSize: 15,
                          fontFamily: 'Roboto')),
                ),
                Container(
                    padding: EdgeInsets.only(top: 20),
                    margin: EdgeInsets.only(bottom: 12),
                    child: Column(
                      children: [
                        Container(
                          width: 300,
                          height: 200,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              image: DecorationImage(
                                  image: AssetImage('assets/img/poster.jpg'),
                                  fit: BoxFit.cover)),
                          child: Column(children: [
                            Container(
                              padding: EdgeInsets.all(10),
                              alignment: Alignment.topRight,
                              child: Icon(Icons.content_cut,
                                  color: Colors.white, size: 20),
                            ),
                            Container(
                                alignment: Alignment.centerLeft,
                                padding: EdgeInsets.only(left: 10),
                                child: Text(
                                  'FRESH',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Roboto',
                                      fontSize: 25,
                                      fontWeight: FontWeight.w200),
                                )),
                            Container(
                                alignment: Alignment.centerLeft,
                                padding: EdgeInsets.only(left: 10),
                                child: Text(
                                  '2x1',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Roboto',
                                      fontSize: 20,
                                      fontWeight: FontWeight.w200),
                                ))
                          ]),
                        )
                      ],
                    )),
                Container(
                  padding: EdgeInsets.only(top: 20),
                  height: 3,
                  width: 300,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xff64371d),
                        Color(0xff00040f),
                        Color(0xffffffff)
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
                Container(
                  alignment: Alignment.centerLeft,
                  margin: EdgeInsets.only(top: 15, bottom: 15, left: 25),
                  child: Text('Servicios',
                      style: TextStyle(
                          color: Color(0xfffffdfd),
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.w300,
                          fontSize: 17)),
                ),
                Container(
                  margin: EdgeInsets.only(left: 25),
                  child: Row(
                    children: [
                      Container(
                        height: 120,
                        width: 150,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                                image: AssetImage('assets/img/precio.jpg'),
                                fit: BoxFit.cover)),
                        child: Column(children: [
                          Container(
                              margin: EdgeInsets.only(top: 10, bottom: 5),
                              alignment: Alignment.topCenter,
                              child: CircleAvatar(
                                child: Icon(Icons.face),
                                backgroundColor: Colors.white,
                                foregroundColor: Colors.black,
                              )),
                          Container(
                            padding: EdgeInsets.only(),
                            alignment: Alignment.topCenter,
                            child: Column(children: [
                              Text(
                                'Catalogo de cortes',
                                style: TextStyle(
                                    color: Colors.white, fontFamily: 'Roboto'),
                              ),
                              Text(' Precios',
                                  style: TextStyle(
                                      color: Color(0xffffffff),
                                      fontFamily: 'Roboto'))
                            ]),
                          )
                        ]),
                      ),
                      Container(
                        margin: EdgeInsets.only(),
                        height: 120,
                        width: 150,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                                image: AssetImage('assets/img/barbero.jpg'),
                                fit: BoxFit.cover)),
                        child: Column(children: [
                          Container(
                              margin: EdgeInsets.only(top: 10, bottom: 5),
                              alignment: Alignment.topCenter,
                              child: CircleAvatar(
                                child: Icon(Icons.assignment_ind),
                                backgroundColor: Colors.white,
                                foregroundColor: Colors.black,
                              )),
                          Container(
                            padding: EdgeInsets.only(),
                            alignment: Alignment.topCenter,
                            child: Column(children: [
                              Text(
                                'Info barberos',
                                style: TextStyle(
                                    color: Colors.white, fontFamily: 'Roboto'),
                              )
                            ]),
                          )
                        ]),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 25),
                  child: Row(
                    children: [
                      Container(
                        height: 120,
                        width: 150,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                                image: AssetImage(
                                    'assets/img/barbershop-4019683_1280.jpg'),
                                fit: BoxFit.cover)),
                        child: Column(children: [
                          Container(
                              margin: EdgeInsets.only(top: 10, bottom: 5),
                              alignment: Alignment.topCenter,
                              child: CircleAvatar(
                                child: Icon(Icons.content_cut),
                                backgroundColor: Colors.white,
                                foregroundColor: Colors.black,
                              )),
                          Container(
                            padding: EdgeInsets.only(),
                            alignment: Alignment.topCenter,
                            child: Column(children: [
                              Text(
                                'Visualización de cortes',
                                style: TextStyle(
                                    color: Colors.white, fontFamily: 'Roboto'),
                              ),
                            ]),
                          )
                        ]),
                      ),
                      Container(
                        margin: EdgeInsets.only(),
                        height: 120,
                        width: 150,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                                image: AssetImage(
                                    'assets/img/barber-1453064_1280.jpg'),
                                fit: BoxFit.cover)),
                        child: Column(children: [
                          Container(
                              margin: EdgeInsets.only(top: 10, bottom: 5),
                              alignment: Alignment.topCenter,
                              child: CircleAvatar(
                                child: Icon(Icons.verified),
                                backgroundColor: Colors.white,
                                foregroundColor: Colors.black,
                              )),
                          Container(
                            padding: EdgeInsets.only(),
                            alignment: Alignment.topCenter,
                            child: Column(children: [
                              Text(
                                'Agendar cita',
                                style: TextStyle(
                                    color: Colors.white, fontFamily: 'Roboto'),
                              ),
                              Text('Disponibilidad',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Roboto'))
                            ]),
                          )
                        ]),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 10, bottom: 15),
                  height: 50,
                  width: 300,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(
                          image:
                              AssetImage('assets/img/barber-1017457_1280.jpg'),
                          fit: BoxFit.cover)),
                  child: Column(children: [
                    Container(
                        padding: EdgeInsets.only(top: 5, left: 10),
                        alignment: Alignment.topLeft,
                        child: Text(
                          'Opinion de clientes',
                          style: TextStyle(
                              color: Colors.white, fontFamily: 'Roboto'),
                        )),
                    Container(
                        padding: EdgeInsets.only(left: 10),
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Califica el servicio',
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Roboto',
                              fontSize: 15),
                        ))
                  ]),
                ),
              ],
            ),
          ),
          bottomNavigationBar: BottomNavigationBar(
            items: [
              BottomNavigationBarItem(
                  icon: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15)),
                    height: 40,
                    width: 80,
                    child: Icon(Icons.home_filled, color: Colors.black),
                  ),
                  label: ''),
              BottomNavigationBarItem(
                  icon: Container(
                    decoration: BoxDecoration(
                        color: Color(0xff825120),
                        borderRadius: BorderRadius.circular(15)),
                    height: 40,
                    width: 80,
                    child: Icon(Icons.settings_accessibility,
                        color: Color(0xff010000)),
                  ),
                  label: ''),
              BottomNavigationBarItem(
                  icon: Container(
                    decoration: BoxDecoration(
                        color: Color(0xff825120),
                        borderRadius: BorderRadius.circular(15)),
                    height: 40,
                    width: 80,
                    child: Icon(Icons.date_range, color: Color(0xff000000)),
                  ),
                  label: ''),
            ],
            elevation: 0,
            backgroundColor: Colors.transparent,
          )

          /*Row(children: [
          Container(
            margin: EdgeInsets.only(left: 30, bottom: 20, right: 30),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(15)),
            height: 40,
            width: 80,
            child: Icon(Icons.home_filled, color: Colors.black),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20, right: 30),
            decoration: BoxDecoration(
                color: Color(0xff8e8e8e),
                borderRadius: BorderRadius.circular(15)),
            height: 40,
            width: 80,
            child: Icon(Icons.devices, color: Colors.black),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20, right: 30),
            decoration: BoxDecoration(
                color: Color(0xff8e8e8e),
                borderRadius: BorderRadius.circular(15)),
            height: 40,
            width: 80,
            child: Icon(Icons.settings, color: Colors.black),
          )
        ]),*/
          ),
    );
  }
}
