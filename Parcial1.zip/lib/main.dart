import 'package:flutter/material.dart';
import 'package:parcial1/src/myApp.dart';

void main() => runApp(myApp());
